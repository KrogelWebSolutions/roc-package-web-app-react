import React from 'react';
import { NavLink } from 'react-router-dom';
import styles from './style.scss';

export default () => (
  <div className={styles.navbar}>
    <div className="wrapper">
      <ul>
        <li>
          <NavLink
            to="/"
            className={styles.a}
            activeClassName={styles.active}
          >
          Home
        </NavLink>
        </li>
        <li>
          <NavLink
            to="/about/"
            className={styles.a}
            activeClassName={styles.active}
          >
            About
          </NavLink>
        </li>
      </ul>
    </div>
  </div>
);
