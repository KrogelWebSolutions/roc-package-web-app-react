import React from 'react';
// import { Route, IndexRoute } from 'react-router';

import App from '../screens/app';
import Start from '../screens/start';
import About from '../screens/about';

// export default () => (
//   <Route component={ App }>
//     <IndexRoute component={ Start } />
//     <Route component={ About } path="/about/" />
//   </Route>
// );

const routes = () => {
  return   [
     {
       path: '/',
       name: 'Start',
       exact: true,
       // tag: RouteAuth,
       component: Start
     },
     {
       path: '/about/',
       name: 'About',
       // tag: Route,
       component: About
     },
   ];
};
export default routes();

// export default () => (
//   [
//    {
//      path: '/',
//      name: 'Dashboard',
//      exact: true,
//      // tag: RouteAuth,
//      component: Dashboard
//    },
//    {
//      path: '/login',
//      name: 'Login',
//      // tag: Route,
//      component: LoginPage
//    },
//    {
//      name: 'Not Found',
//      // tag: Route,
//      component: NotFound
//    }
//  ]
// );
